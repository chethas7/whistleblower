// src/components/RightSidebar.jsx
import { users } from "../data/dummyData";

export default function RightSidebar({ darkMode }) {
  const activities = [
    { user: users[1], action: "liked your post", time: "5 min ago" },
    { user: users[2], action: "commented on your photo", time: "12 min ago" },
    { user: users[3], action: "shared your story", time: "1 hr ago" },
  ];

  const onlineFriends = users.filter((user) => user.isOnline).slice(0, 5);
  const recentChats = users.slice(3, 6); // Example recent chats

  return (
    <div className={`h-full ${darkMode ? "bg-gray-900" : "bg-white"} p-4`}>
      {/* Recent Activity */}
      <div className="mb-6">
        <h3
          className={`font-semibold mb-3 ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          Recent Activity
        </h3>
        <div className="space-y-4">
          {activities.map((activity, index) => (
            <div
              key={index}
              className={`flex items-start p-2 rounded-lg ${
                darkMode ? "hover:bg-gray-800" : "hover:bg-gray-100"
              }`}
            >
              <img
                src={activity.user.avatar}
                alt={activity.user.name}
                className="w-10 h-10 rounded-full mr-3"
              />
              <div>
                <p
                  className={`text-sm ${
                    darkMode ? "text-white" : "text-gray-900"
                  }`}
                >
                  <span className="font-medium">{activity.user.name}</span>{" "}
                  {activity.action}
                </p>
                <p
                  className={`text-xs ${
                    darkMode ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  {activity.time}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Online Friends */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3
            className={`font-semibold ${
              darkMode ? "text-white" : "text-gray-900"
            }`}
          >
            Online Friends
          </h3>
          <button
            className={`text-sm ${
              darkMode ? "text-blue-400" : "text-blue-500"
            }`}
          >
            See All
          </button>
        </div>
        <div className="space-y-3">
          {onlineFriends.map((friend) => (
            <div
              key={friend.id}
              className={`flex items-center p-2 rounded-lg ${
                darkMode ? "hover:bg-gray-800" : "hover:bg-gray-100"
              }`}
            >
              <div className="relative mr-3">
                <img
                  src={friend.avatar}
                  alt={friend.name}
                  className="w-10 h-10 rounded-full object-cover border-2 border-green-500"
                />
                <div
                  className={`absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border ${
                    darkMode ? "border-gray-900" : "border-white"
                  }`}
                ></div>
              </div>
              <div>
                <p
                  className={`font-medium ${
                    darkMode ? "text-white" : "text-gray-900"
                  }`}
                >
                  {friend.name}
                </p>
                <p
                  className={`text-xs ${
                    darkMode ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  Online now
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent Chats */}
      <div>
        <h3
          className={`font-semibold mb-3 ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          Recent Chats
        </h3>
        <div className="space-y-3">
          {recentChats.map((chat) => (
            <div
              key={chat.id}
              className={`flex items-center p-2 rounded-lg ${
                darkMode ? "hover:bg-gray-800" : "hover:bg-gray-100"
              }`}
            >
              <div className="relative mr-3">
                <img
                  src={chat.avatar}
                  alt={chat.name}
                  className="w-10 h-10 rounded-full object-cover"
                />
                {chat.isOnline && (
                  <div
                    className={`absolute bottom-0 right-0 w-2 h-2 bg-green-500 rounded-full border ${
                      darkMode ? "border-gray-900" : "border-white"
                    }`}
                  ></div>
                )}
              </div>
              <div>
                <p
                  className={`font-medium ${
                    darkMode ? "text-white" : "text-gray-900"
                  }`}
                >
                  {chat.name}
                </p>
                <p
                  className={`text-xs ${
                    darkMode ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  {chat.isOnline ? "Online" : "Last seen today"}
                </p>
              </div>
              <button
                className={`ml-auto p-1 rounded-full ${
                  darkMode ? "hover:bg-gray-700" : "hover:bg-gray-200"
                }`}
              >
                <span className="text-lg">💬</span>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
