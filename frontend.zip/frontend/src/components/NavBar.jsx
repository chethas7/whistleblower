// src/components/Navbar.jsx
import { Mail, Search, Sun, Moon } from "lucide-react";
import NavLogo from "./NavLogo";

export default function Navbar({ darkMode, setDarkMode }) {
  return (
    <nav className="fixed top-0 left-0 w-full h-16 bg-white dark:bg-gray-900 shadow-sm flex items-center justify-between px-6 z-50">
      {/* Left: Logo Component */}
      <NavLogo darkMode={darkMode} />

      {/* Center: Search Bar */}
      <div className="flex items-center w-1/2 max-w-md relative">
        <Search
          className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500"
          size={18}
        />
        <input
          type="text"
          placeholder="Search..."
          className="w-full pl-10 py-2 rounded-md bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* Right: Icons + Toggle */}
      <div className="flex items-center gap-4">
        {/* Theme Toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white transition"
        >
          {darkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>

        {/* Whistle Notification */}
        <button className="relative text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white transition">
          <span className="text-2xl">📢</span>
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] rounded-full px-1">
            3
          </span>
        </button>

        {/* Messages */}
        <button className="text-gray-700 dark:text-gray-300 hover:text-black dark:hover:text-white transition">
          <Mail size={20} />
        </button>

        {/* Avatar */}
        <img
          src="https://i.pravatar.cc/32"
          alt="User Avatar"
          className="w-8 h-8 rounded-full object-cover"
        />
      </div>
    </nav>
  );
}
