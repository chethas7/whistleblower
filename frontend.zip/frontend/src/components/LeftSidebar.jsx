// src/components/LeftSidebar.jsx
import { users } from "../data/dummyData";

export default function LeftSidebar({ darkMode }) {
  const currentUser = {
    ...users[0],
    profession: "Senior UX Designer",
    location: "San Francisco, CA",
    education: "Stanford University",
    company: "Meta Inc.",
    joined: "June 2018",
    skills: ["UI/UX", "Figma", "User Research"],
  };

  const friends = users.slice(1, 9); // First 8 friends
  const suggestedFriends = users.slice(3, 6); // 3 suggested friends

  return (
    <div className={`h-full ${darkMode ? "bg-gray-900" : "bg-white"} p-4`}>
      {/* Profile Section */}
      <div
        className={`p-4 rounded-lg ${
          darkMode ? "bg-gray-800" : "bg-gray-50"
        } mb-4`}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="relative">
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-16 h-16 rounded-full object-cover border-2 border-blue-500"
            />
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
          </div>
          <div>
            <h2
              className={`text-lg font-bold ${
                darkMode ? "text-white" : "text-gray-900"
              }`}
            >
              {currentUser.name}
            </h2>
            <p
              className={`text-sm ${
                darkMode ? "text-gray-300" : "text-gray-600"
              }`}
            >
              {currentUser.profession} at {currentUser.company}
            </p>
          </div>
        </div>

        <div
          className={`text-sm ${
            darkMode ? "text-gray-300" : "text-gray-700"
          } space-y-2`}
        >
          <div className="flex items-center gap-2">
            <span>🏠</span>
            <span>Lives in {currentUser.location}</span>
          </div>
          <div className="flex items-center gap-2">
            <span>🎓</span>
            <span>Studied at {currentUser.education}</span>
          </div>
          <div className="flex items-center gap-2">
            <span>💼</span>
            <span>Joined {currentUser.joined}</span>
          </div>
        </div>
      </div>

      {/* Friends Grid */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-3">
          <h3
            className={`font-semibold ${
              darkMode ? "text-white" : "text-gray-900"
            }`}
          >
            Friends ({friends.length})
          </h3>
          <button
            className={`text-sm ${
              darkMode ? "text-blue-400" : "text-blue-500"
            }`}
          >
            See All
          </button>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {friends.map((friend) => (
            <div key={friend.id} className="flex flex-col items-center">
              <div className="relative mb-1">
                <img
                  src={friend.avatar}
                  alt={friend.name}
                  className="w-full aspect-square rounded-lg object-cover"
                />
                {friend.isOnline && (
                  <div
                    className={`absolute bottom-1 right-1 w-2 h-2 bg-green-500 rounded-full border ${
                      darkMode ? "border-gray-900" : "border-white"
                    }`}
                  ></div>
                )}
              </div>
              <p
                className={`text-xs text-center ${
                  darkMode ? "text-white" : "text-gray-700"
                }`}
              >
                {friend.name.split(" ")[0]}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Suggested Friends Column */}
      <div>
        <h3
          className={`font-semibold mb-3 ${
            darkMode ? "text-white" : "text-gray-900"
          }`}
        >
          Suggested Friends
        </h3>
        <div className="space-y-3">
          {suggestedFriends.map((friend) => (
            <div
              key={friend.id}
              className={`flex items-center p-2 rounded-lg ${
                darkMode ? "hover:bg-gray-800" : "hover:bg-gray-100"
              }`}
            >
              <img
                src={friend.avatar}
                alt={friend.name}
                className="w-10 h-10 rounded-full object-cover mr-3"
              />
              <div>
                <p
                  className={`font-medium ${
                    darkMode ? "text-white" : "text-gray-900"
                  }`}
                >
                  {friend.name}
                </p>
                <p
                  className={`text-xs ${
                    darkMode ? "text-gray-400" : "text-gray-500"
                  }`}
                >
                  3 mutual friends
                </p>
              </div>
              <button
                className={`ml-auto text-sm px-3 py-1 rounded-md ${
                  darkMode
                    ? "bg-blue-600 hover:bg-blue-700"
                    : "bg-blue-500 hover:bg-blue-600"
                } text-white`}
              >
                Add
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
