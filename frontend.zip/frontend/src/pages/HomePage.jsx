// src/pages/Home.jsx
import Navbar from "../components/Navbar";
import LeftSidebar from "../components/LeftSidebar";
import MainFeed from "../components/MainFeed";
import RightSidebar from "../components/RightSidebar";

export default function Home({ darkMode, setDarkMode }) {
  return (
    <div className={`min-h-screen ${darkMode ? "bg-gray-900" : "bg-gray-50"}`}>
      {/* Navbar fixed at top */}
      <Navbar darkMode={darkMode} setDarkMode={setDarkMode} />

      {/* Main content area - using flex instead of fixed positioning */}
      <div className="flex pt-16 h-[calc(100vh-4rem)] w-full">
        {/* Left Sidebar - 20% */}
        <div className="w-[20%] h-full overflow-y-auto border-r border-gray-200 dark:border-gray-700">
          <LeftSidebar darkMode={darkMode} />
        </div>

        {/* Main Feed - 60% */}
        <div className="w-[60%] h-full overflow-y-auto">
          <MainFeed darkMode={darkMode} />
        </div>

        {/* Right Sidebar - 20% */}
        <div className="w-[20%] h-full overflow-y-auto border-l border-gray-200 dark:border-gray-700">
          <RightSidebar darkMode={darkMode} />
        </div>
      </div>
    </div>
  );
}
